# NovelCraft · 短期前瞻辅助详细设计包

**版本：** v1.0 · 2026-09-20  
**仓库基线：** `a7173869ca832537cf476e0a05e97f1f5275012a`  
**交付性质：**待实施设计与可校验参考合同；未修改、提交或部署仓库。

目标是让作者在没有明确大纲或伏笔计划时，仍能获得围绕当前任务的短期建议、相关资料、条件式发展方向和操作影响预判，并将能力扩展到九个功能模块。

## 从哪里开始

直接打开 `NovelCraft-短期前瞻辅助-离线阅读版.html`，可离线阅读正文、浏览目录、搜索章节和查看五张架构图。外部链接只用于核对参考来源，不影响正文展示；阅读版不加载远程字体或脚本。

需要实施时，按下表使用可编辑源文件。

| 文件 | 用途 |
|---|---|
| [01-详细设计.md](01-详细设计.md) | 范围、算法、16项不变量、数据、调度、API、交互、权限、预算与回退 |
| [02-模块能力目录.md](02-模块能力目录.md) | 33项能力：触发、输入、输出、动作、边界与实施批次 |
| [03-实施计划与验收.md](03-实施计划与验收.md) | 16个工作包、85个待执行产品用例、部署和验收要求 |
| [04-架构决策与来源索引.md](04-架构决策与来源索引.md) | 12项设计决策、固定源码依据与官方参考 |
| [05-AI分析协议与评估手册.md](05-AI分析协议与评估手册.md) | 观察/问题/方案提示模板、预算闭合、反证复核、盲评方法 |
| [contracts/openapi.yaml](contracts/openapi.yaml) | 24个拟议HTTP操作，作者与RP分路由，未部署 |
| [contracts/forecast_contracts.py](contracts/forecast_contracts.py) | Pydantic参考类型，可独立验证结构和部分跨字段约束 |
| [contracts/schema-reference.sql](contracts/schema-reference.sql) | 两张派生表及兼容扩展的参考DDL，不是已执行迁移 |
| [tests/acceptance-cases.yaml](tests/acceptance-cases.yaml) | 85项未来产品验收场景，全部not_run |
| [tests/work-packages.yaml](tests/work-packages.yaml) | 可供开发任务拆解的16个工作包及依赖 |
| [验证记录.md](验证记录.md) | 本次实际完成的局部校验及明确未执行的验证 |

`contracts/schemas.json` 与 OpenAPI 来自同一参考类型；`examples/` 提供五个虚构请求/响应 fixture；`diagrams/` 包含五张 SVG 及其可编辑 DOT 源。

## 先读的设计决定

Assistant 编排和呈现，Evidence 控制读取与安全投影，原领域拥有事实和采用。首版不迁移编排框架，不新建通用记忆或事实平台。默认只分析已保存文本，自动联网关闭；推测保留未知，作者选择后才进入原领域预览和确认。

先落实B1写作闭环，而不是先把所有模块都变成聊天框。B1必须包含有用的正向接续或创作机会，不以风险提示和基础设施代替产品交付。

## 运行本包校验

在有 Python 3.11+ 的独立环境中，安装 `requirements-validation.txt` 后执行：

```bash
python -m pip install -r requirements-validation.txt
python -m pytest tests/test_contracts.py tests/test_document_consistency.py -q
```

测试没有连接用户数据库，没有调用真实模型，没有实现实际API，也没有执行85项产品场景。Pydantic接受某个UUID不证明调用者有权限；这些检查必须在真实应用里另行完成。

`schema-reference.sql` 不能直接应用到生产。正式实施必须先核对真实迁移head、原ORM约束和已有notice/policy的全部修改路径，再生成与现库兼容的Alembic迁移。

## 文档更新与追溯

各章节的 `[Sxx]` 指向固定仓库来源，`[Rxx]` 指向官方参考；具体参数和门槛均为设计初值，不是外部资料给出的事实。所有新增接口、表、开关和路径都明确属于拟议实现。基线后仓库若有变化，先更新差异记录，再实施对应工作包。
