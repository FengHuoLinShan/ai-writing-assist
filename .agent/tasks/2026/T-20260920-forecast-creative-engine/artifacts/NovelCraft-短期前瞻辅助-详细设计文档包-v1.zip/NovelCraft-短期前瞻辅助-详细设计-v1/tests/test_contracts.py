"""Local documentation-contract tests only; not tests of the user repository."""
from __future__ import annotations
import copy
import json
from pathlib import Path
import sys
import pytest
from pydantic import ValidationError

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / 'contracts'))
import forecast_contracts as c


def load(name: str):
    return json.loads((ROOT / 'examples' / name).read_text(encoding='utf-8'))


@pytest.mark.parametrize('name,model', [
    ('evaluate-author.json', c.EvaluateRequest),
    ('feed-response.json', c.FeedResponse),
    ('decision-snooze.json', c.DecisionRequest),
    ('prepare-request.json', c.PrepareRequest),
    ('policy-update.json', c.PolicyUpdate),
])
def test_examples_roundtrip(name, model):
    obj = model.model_validate(load(name))
    assert model.model_validate_json(obj.model_dump_json()) == obj


@pytest.mark.parametrize('field', ['novel_id','owner_id','provider','api_key','confirmed','scope_hash'])
def test_browser_cannot_supply_authority_fields(field):
    data = load('evaluate-author.json')
    data[field] = 'injected'
    with pytest.raises(ValidationError):
        c.EvaluateRequest.model_validate(data)


@pytest.mark.parametrize('start,end', [(-1,1),(0,0),(4,3),(4,4)])
def test_bad_ranges(start,end):
    with pytest.raises(ValidationError):
        c.TextRange(start_offset=start,end_offset=end)


def test_start_zero_is_valid():
    assert c.TextRange(start_offset=0,end_offset=1).start_offset == 0


def test_selected_range_needs_source():
    data = load('evaluate-author.json')['context']
    data.pop('draft_id'); data.pop('expected_source_hash')
    data['selected_range'] = {'start_offset':0,'end_offset':1}
    with pytest.raises(ValidationError): c.FocusRequest.model_validate(data)


@pytest.mark.parametrize('missing',['context_confirmation_id','context_confirmation_action'])
def test_confirmation_pair(missing):
    data = load('evaluate-author.json')['context']
    data['context_confirmation_id'] = '00000000-0000-4000-8000-000000000888'
    data['context_confirmation_action'] = 'writing.generate'
    data[missing] = None
    with pytest.raises(ValidationError): c.FocusRequest.model_validate(data)


@pytest.mark.parametrize('model,fixture', [(c.EvaluateRequest,'evaluate-author.json'),(c.PrepareRequest,'prepare-request.json')])
def test_dirty_rejected_for_compute_or_prepare(model, fixture):
    data = load(fixture); data['context']['editor_state'] = 'dirty'
    with pytest.raises(ValidationError): model.model_validate(data)


def test_dirty_allowed_for_readonly_feed():
    focus=load('evaluate-author.json')['context']; focus['editor_state']='dirty'
    assert c.FeedRequest(context=focus).context.editor_state == 'dirty'


@pytest.mark.parametrize('unit', ['scene','interaction_beat'])
def test_narrative_horizon_not_three(unit):
    with pytest.raises(ValidationError): c.Horizon(unit=unit,steps=3)


def test_operation_horizon_can_be_three():
    assert c.Horizon(unit='operation',steps=3).steps==3


def test_causal_depth_bounded():
    with pytest.raises(ValidationError): c.Horizon(unit='operation',causal_depth=3)


def test_observed_requires_evidence():
    with pytest.raises(ValidationError): c.Statement(text='He left.',basis='observed')


def test_new_creative_proposal_needs_no_past_source():
    assert c.Statement(text='A bell may interrupt the conversation.',basis='proposed').evidence_ids == []


def test_candidate_evidence_must_resolve_locally():
    obj=load('feed-response.json')['items'][0]
    obj['statements'][0]['evidence_ids']=['invented']
    with pytest.raises(ValidationError): c.CandidateView.model_validate(obj)


def test_duplicate_evidence_ids_rejected():
    obj=load('feed-response.json')['items'][0]; obj['evidence'].append(copy.deepcopy(obj['evidence'][0]))
    with pytest.raises(ValidationError): c.CandidateView.model_validate(obj)


def test_domain_verified_needs_finding():
    obj=load('feed-response.json')['items'][0]; obj['verification_status']='domain_verified'
    with pytest.raises(ValidationError): c.CandidateView.model_validate(obj)


@pytest.mark.parametrize('freshness',['stale','revoked','expired'])
def test_invalid_candidate_cannot_prepare(freshness):
    obj=load('feed-response.json')['items'][0]; obj['freshness']=freshness
    with pytest.raises(ValidationError): c.CandidateView.model_validate(obj)


def test_unavailable_action_explains_reason():
    with pytest.raises(ValidationError): c.ActionView(action_id='test',label='test',kind='inspect',requires_confirmation=False,available=False)


def test_prepare_never_waives_confirmation():
    with pytest.raises(ValidationError): c.ActionView(action_id='test',label='test',kind='prepare_domain',requires_confirmation=False,available=True)


def test_coverage_conservation():
    obj=load('feed-response.json')['coverage']; obj['enumerated_total']+=1
    with pytest.raises(ValidationError): c.CoverageReport.model_validate(obj)


def test_coverage_nonnegative():
    with pytest.raises(ValidationError): c.CoverageCounts(not_checked=-1)


@pytest.mark.parametrize('state',['empty','disabled','unavailable','not_checked'])
def test_nonready_feed_has_no_active_items(state):
    obj=load('feed-response.json'); obj['state']=state
    with pytest.raises(ValidationError): c.FeedResponse.model_validate(obj)


def test_feed_no_duplicate_assessment():
    obj=load('feed-response.json'); obj['items'].append(copy.deepcopy(obj['items'][0]))
    with pytest.raises(ValidationError): c.FeedResponse.model_validate(obj)


def test_snooze_needs_condition():
    obj=load('decision-snooze.json'); obj['wake_condition']=None
    with pytest.raises(ValidationError): c.DecisionRequest.model_validate(obj)


def test_non_snooze_has_no_wake_condition():
    obj=load('decision-snooze.json'); obj['action']='read'
    with pytest.raises(ValidationError): c.DecisionRequest.model_validate(obj)


def test_reject_direction_requires_id():
    obj=load('decision-snooze.json'); obj.update(action='not_this_direction',wake_condition=None)
    with pytest.raises(ValidationError): c.DecisionRequest.model_validate(obj)


def test_other_decision_cannot_carry_direction():
    obj=load('decision-snooze.json'); obj.update(action='read',wake_condition=None,direction_id='some_direction')
    with pytest.raises(ValidationError): c.DecisionRequest.model_validate(obj)


def test_wake_time_requires_timezone():
    with pytest.raises(ValidationError): c.WakeAt(kind='at_time',at='2026-09-20T09:00:00')


def test_reappearance_requires_after_event():
    with pytest.raises(ValidationError): c.WakeReappearance(kind='object_reappears',object_id='00000000-0000-4000-8000-000000000888',after_event_token='')


def test_disposition_cannot_claim_domain_change():
    with pytest.raises(ValidationError): c.DecisionReceipt(candidate_id='00000000-0000-4000-8000-000000000888',notice_version=1,notice_status='read',disposition='read',domain_state_changed=True)


def test_honest_unknown_usage():
    with pytest.raises(ValidationError): c.UsageView(requests=1,usage_complete=True)
    assert c.UsageView(requests=1,usage_complete=False).input_tokens is None


def test_policy_automatic_requires_enable():
    with pytest.raises(ValidationError): c.ForecastPolicy(enabled=False,automatic=True)


def test_policy_web_disabled_v1():
    with pytest.raises(ValidationError): c.ForecastPolicy(allow_web=True)


def test_policy_timezone_validated():
    with pytest.raises(ValidationError): c.ForecastPolicy(timezone='Unknown/Timezone')


def test_proposal_has_no_execution_fields():
    obj=load('feed-response.json')['items'][0]
    data={key:obj[key] for key in ['title','kind','statements','why_now','directions','unknowns']}
    data['verdict']='propose'; data['actions']=obj['actions']
    with pytest.raises(ValidationError): c.CandidateProposal.model_validate(data)


def test_directions_limited():
    obj=load('feed-response.json')['items'][0]; obj['directions']*=4
    with pytest.raises(ValidationError): c.CandidateView.model_validate(obj)


def test_rp_scope_requires_path_and_epochs():
    uid='00000000-0000-4000-8000-000000000888'
    data=dict(novel_id=uid,owner_id=uid,persona='rp',audience_key='rp:test',scope_hash='a'*64,context_hash='a'*64,policy_generation=1,source_manifest_hash='a'*64)
    with pytest.raises(ValidationError): c.ResolvedScope.model_validate(data)
    data.update(journey_id=uid,selected_path_hash='b'*64,selection_epoch=0,source_context_epoch=0)
    assert c.ResolvedScope.model_validate(data).selection_epoch == 0


def test_author_scope_cannot_have_rp_fields():
    uid='00000000-0000-4000-8000-000000000888'
    data=dict(novel_id=uid,owner_id=uid,persona='author',audience_key='author',scope_hash='a'*64,context_hash='a'*64,policy_generation=1,source_manifest_hash='a'*64,journey_id=uid)
    with pytest.raises(ValidationError): c.ResolvedScope.model_validate(data)


def test_reference_scope_does_not_claim_real_acl():
    # Acceptance only proves shape: random IDs validate, so real owner checks remain mandatory.
    uid='00000000-0000-4000-8000-000000000888'
    assert c.ResolvedScope(novel_id=uid,owner_id=uid,persona='author',audience_key='author',scope_hash='a'*64,context_hash='a'*64,policy_generation=1,source_manifest_hash='a'*64).novel_id


def test_preparation_preview_requires_real_batch_pair():
    uid='00000000-0000-4000-8000-000000000888'
    with pytest.raises(ValidationError): c.PreparationReceipt(operation_id=uid,run_id=uid,parent_forecast_run_id=uid,status='preview_ready')


def test_preparation_is_not_domain_write():
    uid='00000000-0000-4000-8000-000000000888'
    with pytest.raises(ValidationError): c.PreparationReceipt(operation_id=uid,run_id=uid,parent_forecast_run_id=uid,status='pending',domain_write_performed=True)


def test_legacy_middleware_error():
    assert c.MiddlewareError.model_validate({'detail':'Invalid CSRF token'}).detail
