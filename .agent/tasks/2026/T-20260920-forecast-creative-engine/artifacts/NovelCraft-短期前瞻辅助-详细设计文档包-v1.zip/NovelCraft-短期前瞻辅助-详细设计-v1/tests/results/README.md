# 本包局部校验输出

contracts-junit.xml 记录独立文档契约 pytest，不是用户仓库测试。html-checks.json 记录离线阅读版渲染与链接检查。未运行数据库迁移、产品端到端、真实模型或85项AT验收。
