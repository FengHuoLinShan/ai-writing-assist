"""Machine-readable artifact consistency; does not validate business services."""
from __future__ import annotations
import json
import re
from pathlib import Path
import pytest
import yaml
from jsonschema import Draft202012Validator
ROOT=Path(__file__).resolve().parents[1]
SPEC=yaml.safe_load((ROOT/'contracts/openapi.yaml').read_text())
CAPS=yaml.safe_load((ROOT/'contracts/capabilities.yaml').read_text())['capabilities']


def walk(node):
    if isinstance(node,dict):
        yield node
        for v in node.values():yield from walk(v)
    elif isinstance(node,list):
        for v in node:yield from walk(v)


def test_every_openapi_ref_resolves():
    for obj in walk(SPEC):
        if '$ref' not in obj:continue
        ref=obj['$ref']; assert ref.startswith('#/')
        target=SPEC
        for component in ref[2:].split('/'):
            target=target[component.replace('~1','/').replace('~0','~')]
        assert isinstance(target,dict)


def test_json_schema_meta_valid():
    for schema in SPEC['components']['schemas'].values():
        Draft202012Validator.check_schema(schema)


def test_schema_artifacts_match():
    standalone=json.loads((ROOT/'contracts/schemas.json').read_text())
    assert standalone['components']['schemas']==SPEC['components']['schemas']


def test_api_unique_operation_ids():
    ids=[obj['operationId'] for methods in SPEC['paths'].values() for obj in methods.values()]
    assert len(ids)==len(set(ids))==24


def test_route_persona_and_middleware():
    assert SPEC['components']['securitySchemes']['accountSession']['name']=='aaw_session'
    for path,methods in SPEC['paths'].items():
        assert '/api/interaction/' not in path
        for method,obj in methods.items():
            names={p['name'] for p in obj['parameters']}
            if path.startswith('/api/interactions/'):
                assert 'journey_id' in names and 'novel_id' not in names
            else:assert 'novel_id' in names
            if method!='get':assert {'X-CSRF-Token','Origin'}<=names
            assert '403' in obj['responses']


def test_all_modules_registered_once_per_capability():
    assert len(CAPS)==33
    assert len({x['capability_id'] for x in CAPS})==len(CAPS)
    assert {x['owner_domain'] for x in CAPS}=={'account','assistant','evidence','imports','interaction','project','story','world','writing'}
    assert all(x['status']=='proposed' and x['default_enabled'] is False for x in CAPS)


def test_catalog_ids_in_readable_document():
    text=(ROOT/'02-模块能力目录.md').read_text()
    for cap in CAPS:assert f"### {cap['capability_id']}" in text


def test_example_capabilities_registered():
    registry={x['capability_id'] for x in CAPS}
    data=json.loads((ROOT/'examples/evaluate-author.json').read_text())
    assert set(data['requested_capabilities'])<=registry


def test_references_defined_and_pinned():
    refs=json.loads((ROOT/'sources.json').read_text()); ids={r['id'] for r in refs}
    assert len(ids)==len(refs)
    for file in ROOT.glob('*.md'):
        used=set(re.findall(r'\[((?:S|R)\d{2})\]',file.read_text()))
        assert used<=ids,(file.name,used-ids)
    sha='a7173869ca832537cf476e0a05e97f1f5275012a'
    assert all(sha in r['url'] for r in refs if r['id'].startswith('S'))


def test_future_acceptance_is_not_claimed_run():
    cases=yaml.safe_load((ROOT/'tests/acceptance-cases.yaml').read_text())['cases']
    assert len(cases)==85
    assert len({x['id'] for x in cases})==85
    assert all(x['status']=='not_run' for x in cases)
    invariants=set()
    for x in cases:invariants.update(x['invariants'])
    assert invariants=={f'I{i:02d}' for i in range(1,17)}


def test_work_package_graph_acyclic():
    packages=yaml.safe_load((ROOT/'tests/work-packages.yaml').read_text())['packages']
    assert len(packages)==16
    graph={x['id']:x['depends_on'] for x in packages}
    seen=set(); visiting=set()
    def visit(key):
        assert key in graph
        assert key not in visiting,'dependency cycle'
        if key in seen:return
        visiting.add(key)
        for parent in graph[key]:visit(parent)
        visiting.remove(key);seen.add(key)
    for key in graph:visit(key)


def test_no_tool_citation_or_placeholder_in_artifacts():
    for file in ROOT.rglob('*'):
        if file.suffix not in {'.md','.yaml','.json','.sql'}:continue
        text=file.read_text()
        assert '__REPLACE_WITH_' not in text,file
        assert 'filecite' not in text,file
        assert '... (truncated)' not in text,file


def test_reference_sql_labeled_and_tenant_foreign_key_present():
    sql=(ROOT/'contracts/schema-reference.sql').read_text()
    assert 'NOT executed' in sql
    assert 'FOREIGN KEY(novel_id,run_id)' in sql
    assert 'FOREIGN KEY(novel_id,candidate_id)' in sql
    assert 'Latest first, validity second' in sql
