-- Forecast v1 REFERENCE DDL. NOT an Alembic migration. NOT executed on the user's DB.
-- Preflight must compare the real metadata and existing migration heads.
-- Assumes projects(id) and assistant_runs UNIQUE(novel_id,id), verified in baseline docs/ORM.
-- UUID values are supplied by the application; no extension installation is required here.
BEGIN;
ALTER TABLE assistant_runs ADD COLUMN operation_id uuid NULL;
CREATE UNIQUE INDEX uq_assistant_forecast_operation
  ON assistant_runs(novel_id, operation_id) WHERE operation_id IS NOT NULL;
ALTER TABLE assistant_notices ADD COLUMN row_version integer NOT NULL DEFAULT 0;
ALTER TABLE assistant_notices ADD CONSTRAINT ck_assistant_notice_row_version CHECK (row_version >= 0);

CREATE TABLE assistant_forecast_candidates (
  id uuid PRIMARY KEY,
  novel_id uuid NOT NULL REFERENCES projects(id) ON DELETE CASCADE,
  run_id uuid NOT NULL,
  ordinal smallint NOT NULL CHECK (ordinal BETWEEN 0 AND 63),
  issue_key varchar(160) NOT NULL,
  audience_key varchar(160) NOT NULL,
  scope_hash char(64) NOT NULL CHECK (scope_hash ~ '^[0-9a-f]{64}$'),
  context_hash char(64) NOT NULL CHECK (context_hash ~ '^[0-9a-f]{64}$'),
  assessment_hash char(64) NOT NULL CHECK (assessment_hash ~ '^[0-9a-f]{64}$'),
  capability_id varchar(102) NOT NULL,
  protocol_version varchar(40) NOT NULL,
  output_kind varchar(32) NOT NULL CHECK (output_kind IN
    ('prepared_reference','next_step','creative_opportunity','impact_preview','decision_prompt')),
  tier varchar(16) NOT NULL CHECK (tier IN ('attention','next','watch')),
  policy_generation integer NOT NULL CHECK (policy_generation >= 0),
  validation_state varchar(16) NOT NULL DEFAULT 'valid'
    CHECK (validation_state IN ('valid','stale','revoked','expired')),
  payload_json jsonb NOT NULL CHECK (jsonb_typeof(payload_json) = 'object')
    CHECK (octet_length(payload_json::text) <= 65536),
  expires_at timestamptz NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now(),
  CONSTRAINT uq_forecast_candidate_novel UNIQUE(novel_id,id),
  CONSTRAINT uq_forecast_candidate_run_ordinal UNIQUE(novel_id,run_id,ordinal),
  CONSTRAINT fk_forecast_run_novel FOREIGN KEY(novel_id,run_id)
    REFERENCES assistant_runs(novel_id,id) ON DELETE CASCADE,
  CHECK (expires_at > created_at)
);
CREATE INDEX ix_forecast_latest ON assistant_forecast_candidates
  (novel_id,audience_key,scope_hash,issue_key,created_at DESC,id DESC);
CREATE INDEX ix_forecast_expiry ON assistant_forecast_candidates
  (novel_id,validation_state,expires_at);

CREATE TABLE assistant_forecast_dependencies (
  novel_id uuid NOT NULL,
  candidate_id uuid NOT NULL,
  dependency_key varchar(200) NOT NULL,
  resource_kind varchar(64) NOT NULL,
  resource_id uuid NOT NULL,
  revision_token varchar(200) NOT NULL,
  role varchar(32) NOT NULL CHECK (role IN
    ('content','discovery','authorization','negative_lookup','source_manifest','view_epoch')),
  required boolean NOT NULL DEFAULT true,
  scope_stamp char(64) NULL CHECK (scope_stamp IS NULL OR scope_stamp ~ '^[0-9a-f]{64}$'),
  PRIMARY KEY(candidate_id,dependency_key),
  FOREIGN KEY(novel_id,candidate_id)
    REFERENCES assistant_forecast_candidates(novel_id,id) ON DELETE CASCADE
);
CREATE INDEX ix_forecast_dependency_source ON assistant_forecast_dependencies
  (novel_id,resource_kind,resource_id);

-- Immutable assessment content. Validity is an invalidation projection, not a new truth verdict.
CREATE FUNCTION forecast_candidate_immutable_v1() RETURNS trigger LANGUAGE plpgsql AS $$
BEGIN
  IF (to_jsonb(NEW) - 'validation_state') IS DISTINCT FROM (to_jsonb(OLD) - 'validation_state') THEN
    RAISE EXCEPTION 'Forecast assessments are append-only; create a new assessment';
  END IF;
  IF OLD.validation_state <> 'valid' AND NEW.validation_state = 'valid' THEN
    RAISE EXCEPTION 'Do not resurrect an invalid assessment; reassess';
  END IF;
  RETURN NEW;
END;
$$;
CREATE TRIGGER trg_forecast_candidate_immutable_v1 BEFORE UPDATE
  ON assistant_forecast_candidates FOR EACH ROW EXECUTE FUNCTION forecast_candidate_immutable_v1();
COMMIT;

-- Latest first, validity second: filtering valid inside the CTE would resurrect old advice.
-- Replace bind parameters only via the DB driver. This query is a design example, not a migration step.
-- WITH latest AS (
--   SELECT DISTINCT ON (issue_key) * FROM assistant_forecast_candidates
--   WHERE novel_id=:novel_id AND audience_key=:audience_key AND scope_hash=:scope_hash
--   ORDER BY issue_key,created_at DESC,id DESC
-- ) SELECT * FROM latest WHERE validation_state='valid' AND expires_at > now();
-- Every selected row still needs current authorization, scope/manifest and source revalidation.
