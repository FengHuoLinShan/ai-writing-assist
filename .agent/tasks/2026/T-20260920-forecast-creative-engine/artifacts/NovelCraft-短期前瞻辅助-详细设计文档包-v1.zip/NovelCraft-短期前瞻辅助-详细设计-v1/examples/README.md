# 示例说明

全部示例均为虚构 fixture，不是用户真实小说、真实 source hash 或可直接访问的 ID。请求/响应已通过本包 Pydantic 类型验证；schema 无法证明账户权限、引用真实存在或业务可执行性。示例固定日期仅用于重放，不代表生产 TTL 或调度时间。

作者请求使用 novel_id 查询参数；RP 请求使用 journey 路由，同一请求体不得加入 novel_id/owner_id。所有业务动作仍需实际应用服务重验。
